<nav x-data="{ open: false }" class="bg-white border-b border-gray-100" style="padding: 10px;">
    <!-- Primary Navigation Menu -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" style="position: sticky;">
        <div class="flex justify-between h-16" style="background: url('https://static.wixstatic.com/media/4bdd77_d8f0ff0492f84ec39c67a31971f9e88a~mv2.png/v1/fill/w_1737,h_498,al_c,q_90/4bdd77_d8f0ff0492f84ec39c67a31971f9e88a~mv2.webp'); background-size:contain; background-repeat: no-repeat">

</nav>